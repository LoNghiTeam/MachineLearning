# texxeract
A machine learning web app that detects Text and useful Information from images.
https://youtu.be/zXo5rMVq3gg
